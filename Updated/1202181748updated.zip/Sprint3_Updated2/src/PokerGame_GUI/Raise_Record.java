package PokerGame_GUI;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Raise_Record {
    
	// Write to File after raise button is click
	public void write_to_csv() throws FileNotFoundException {
		String file_name = "record.csv";
		PrintWriter w = new PrintWriter(file_name);
		// ActionPeformed and ActionListener code
	    w.println();
		w.close();
	}

}
