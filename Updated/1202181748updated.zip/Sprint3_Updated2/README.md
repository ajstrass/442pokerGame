# CSE442


# Poker Game Description:
  ## Given a table and 2-10 player, we are going to play poker game. The game will started at clockwise position. At Round 1 also called Pre-Flop Round, at this stage each player bet with their best 2 hidden cards. During the "underground position", a player have 3 options to play which is Fold,Call, and Raise. Round 1 completed when all player folded or commited same amount of poker chips to pot.
  
=======
https://github.com/CSE442fall2018nb/CSE442_Poker_Game/blob/master/src/Pokergame.jar
 
# Poker game Interface :
   1. login page
   2. money
   3. start screen
   4. Game 
   naibingj-README
      ### 4.1 Fold
      ### 4.2 Call
      ### 4.3 raise
=======
   4.1 Fold
   4.2 Call
   4.3 raise
 master
   5. web page game
# goal of the game

   1. determine the best hand
   2. start money ---> each player may raise money.
   
# user stories 
    
    #maintaing a good user story is essentially useful to help meet the requirement of whato other needed.
    As a <role>, I want <feature> so that <reason>.

# FAQ 

  ## Q1: What is difference between big blind and small blind ?
  ## A1: In poker game, we will have a button to mark the status of player position. The person to the left of teh dealer button is called small blind and the person next to smalll blind is called big blind .
=======

